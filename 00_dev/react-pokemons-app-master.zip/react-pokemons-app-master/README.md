# Apprendre React: Développez facilement votre première application avec TypeScript !
*Ce dépôt Github contient le code de la correction de la formation "Apprendre React".*
<img width="400" height="640" src="./learn-react-cover.jpg"/>